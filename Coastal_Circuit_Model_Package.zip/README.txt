海岸山路赛道 · Coastal Circuit

依据用户提供的海岸公路插画制作的可编辑场景。包含发卡弯、石拱桥、
石灰岩海岸、地中海植被、红瓦村落、灯塔和海面。
这是风格与地标的几何近似，不是对原图每一处细节的精确复制。
原图未展示完整路线，因此增加内陆回程，组成闭合赛道。

文件
Coastal_Circuit.blend — 场景源文件，路面、地形、桥梁、建筑、植被、海面分组。
Coastal_Circuit.glb — 可视场景，基础 PBR 材质，不含摄影机和渲染云朵。
Road_Collision.glb — 独立路面碰撞网格，不含护栏/岩石/建筑碰撞。
track_route.json — 路线采样、检查点、出生位置，分别说明 Blender 与 glTF 坐标。
track_audit.json — 实际路长、坡度、三角面数与几何检查记录。
preview_coast.png / preview_layout.png — 实际场景渲染与俯视路线图。
build_track.py — 可复现 Blender Python 脚本。

接入游戏
1. 按米导入。Blender 为 Z 向上，GLB 为 Y 向上。
2. road_width_m 为完整路面宽度，石质护栏在可行驶路面之外。
3. 将 Road_Collision.glb 设为静态三角网格碰撞体；可视场景不自动具有物理碰撞。
4. 路线采样首尾循环，末点应连接首点。检查点顺序按数组顺序。
5. 出生点只给车体参考位置，车辆悬挂/轮半径应由游戏内自行调整。
6. 水面动画、海浪着色、天空和植被 LOD 需游戏端配置。

限制
无车辆控制器、圈速逻辑、AI 寻路、地面摩擦设置或自动物理仿真。
海面在 Blender 中含程序化凹凸；GLB 保留基础色/粗糙度而非同等复杂海浪材质。
碰撞体仅覆盖道路，两侧护栏需按游戏需求单独添加简化碰撞。
此版本为场景资产，未经特定游戏引擎性能/碰撞实车测试。

本版实际规格
闭合路线 1,105.87 米，路面宽 8 米，最大坡度 10.49%。
全景 GLB 为 195,198 三角面；路面碰撞 GLB 为 3,840 三角面。
GLB 将静态物件合批为 6 个网格、44 个材质图元，便于 Web3D 使用；
Blender 源文件仍保留独立可编辑物件。实际帧率仍取决于目标设备和引擎。
原图是高细节插画，本模型采用风格化低多边形表达，未复刻照片级植被、
体积云、海浪或建筑细节，也不应把预览视为原图级别的画质。

验证
960 个中心线采样，首尾连续。道路与实际地形射线检查没有埋入路面。
碰撞网格重新导入后有两条闭合边界（道路左右边缘），无分叉非流形边。
检查记录见 validation_results.json。

复现顺序
blender -b --python build_track.py
blender -b --python optimize_export.py
blender -b --python validate_track.py
blender -b --python render_detail.py
附加 preview_hairpin.png 为近景构图；preview_coast.png 为整体场景，
preview_layout.png 为俯视路线图。
