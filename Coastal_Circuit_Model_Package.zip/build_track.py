import bpy, math, random, json, os
import numpy as np
from mathutils import Vector
from math import sin,cos,pi
random.seed(17)
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in bpy.data.collections:
 if d.name!='Collection': bpy.data.collections.remove(d)
cols={}
for n in ['ROAD','TERRAIN','BRIDGE','VILLAGE','VEGETATION','WATER','SKY','STUDIO','COLLISION']:
 c=bpy.data.collections.new(n); bpy.context.scene.collection.children.link(c); cols[n]=c

def link(o,cat):
 for c in list(o.users_collection):c.objects.unlink(o)
 cols[cat].objects.link(o)
 return o

def mat(n,c,rough=.7,metal=0):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 return m
stone=[mat('Limestone '+str(i),c) for i,c in enumerate([(0.68,.60,.44),(.79,.72,.57),(.61,.55,.43),(.86,.78,.60)])]
grass=[mat('Dry meadow '+str(i),c) for i,c in enumerate([(.25,.32,.07),(.28,.35,.085),(.22,.30,.06),(.31,.37,.10)])]
leaves=[mat('Pine foliage '+str(i),c) for i,c in enumerate([(.15,.25,.045),(.23,.32,.065),(.31,.36,.075),(.12,.23,.08)])]
trunk=mat('Warm bark',(.24,.15,.075)); asphalt=mat('Weathered asphalt',(.12,.135,.14),.94);paint=mat('Ivory road markings',(.9,.86,.68));roof=mat('Terracotta roof',(.49,.15,.065));plaster=[mat('Warm plaster '+str(i),c) for i,c in enumerate([(.87,.79,.60),(.76,.65,.44),(.91,.85,.70)])];dark=mat('Window recess',(.055,.105,.115));wood=mat('Shutters',(.15,.23,.16));red=mat('Lighthouse vermilion',(.57,.12,.06));foam=mat('Sea foam',(.65,.87,.80));sand=mat('Beach sand',(.73,.63,.43));water=mat('Mediterranean blue',(.015,.29,.39),.22,.15)
wp=water.node_tree.nodes.get('Principled BSDF');wp.inputs['IOR'].default_value=1.333
noise=water.node_tree.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=1.6;noise.inputs['Detail'].default_value=2
bump=water.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.28;bump.inputs['Distance'].default_value=.3;water.node_tree.links.new(noise.outputs['Fac'],bump.inputs['Height']);water.node_tree.links.new(bump.outputs['Normal'],wp.inputs['Normal'])

def mesh(n,v,f,m,cat,smooth=False):
 me=bpy.data.meshes.new(n);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(n,me);cols[cat].objects.link(o)
 for mm in (m if isinstance(m,list) else [m]):me.materials.append(mm)
 if smooth:
  for p in me.polygons:p.use_smooth=True
 return o

def cube(n,loc,scale,m,cat,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);link(o,cat)
 if bevel:
  mod=o.modifiers.new('Soft edges','BEVEL');mod.width=bevel;mod.segments=1;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 return o

def ico(n,loc,scale,m,cat,sub=1):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=1,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(m);link(o,cat);return o

def cyl(n,loc,r,depth,m,cat,vertices=12,r2=None):
 bpy.ops.mesh.primitive_cone_add(vertices=vertices,radius1=r,radius2=r if r2 is None else r2,depth=depth,location=loc);o=bpy.context.object;o.name=n;o.data.materials.append(m);link(o,cat);return o

def beam(n,a,b,r,m,cat,verts=8):
 a,b=Vector(a),Vector(b);o=cyl(n,(a+b)/2,r,(b-a).length,m,cat,verts);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o

# Fast direct mesh helpers avoid per-object dependency graph updates.
def cube(n,loc,scale,m,cat,bevel=0):
 v=[(a*scale[0]/2,b*scale[1]/2,c*scale[2]/2) for a,b,c in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]]
 o=mesh(n,v,[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)],m,cat);o.location=loc;return o
ico_cache={}
def ico(n,loc,scale,m,cat,sub=1):
 if sub not in ico_cache:
  bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=1);ob=bpy.context.object;ico_cache[sub]=( [tuple(v.co) for v in ob.data.vertices],[tuple(p.vertices) for p in ob.data.polygons]);bpy.data.objects.remove(ob,do_unlink=True)
 vv,ff=ico_cache[sub];o=mesh(n,vv,ff,m,cat);o.location=loc;o.scale=scale;return o
def cyl(n,loc,r,depth,m,cat,vertices=12,r2=None):
 rt=r if r2 is None else r2;v=[]
 for z,rr in [(-depth/2,r),(depth/2,rt)]:
  v.extend([(rr*cos(j*2*pi/vertices),rr*sin(j*2*pi/vertices),z) for j in range(vertices)])
 f=[tuple(reversed(range(vertices))),tuple(range(vertices,2*vertices))]
 for j in range(vertices):k=(j+1)%vertices;f.append((j,k,k+vertices,j+vertices))
 o=mesh(n,v,f,m,cat);o.location=loc;return o
print('BUILD start',flush=True)
P=np.array([[-140,-70,25],[-112,-101,23],[-72,-94,22],[-48,-65,23],[-65,-34,26],[-105,-31,30],[-128,-5,34],[-106,26,37],[-65,37,35],[-40,18,29],[-15,-10,24],[25,-10,24],[61,-2,24],[80,31,27],[106,65,30],[122,105,34],[99,141,38],[40,158,43],[-26,151,46],[-95,147,48],[-149,116,44],[-173,66,36],[-180,5,29],[-172,-43,26]],float)
P[:,2]=24+(P[:,2]-24)*.5
N=960; path=[]
for k in range(N):
 u=k/N*len(P);i=int(u);t=u-i;p0,p1,p2,p3=[P[j%len(P)] for j in [i-1,i,i+1,i+2]]
 path.append(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
path=np.array(path);tang=np.roll(path,-1,axis=0)-np.roll(path,1,axis=0);normal=np.stack([-tang[:,1],tang[:,0],np.zeros(N)],axis=1);normal/=np.linalg.norm(normal,axis=1)[:,None]
seg=np.roll(path,-1,axis=0)-path;dist=np.linalg.norm(seg,axis=1);length=float(dist.sum());grade=np.abs(seg[:,2])/np.linalg.norm(seg[:,:2],axis=1)
bridge_mask=(path[:,0]>-16)&(path[:,0]<59)&(path[:,1]<4)&(path[:,1]>-18)
# full-width strip uses counterclockwise faces; smooth crown 4 cm
verts=[]
for p,n in zip(path,normal):
 for w in [-4,0,4]:verts.append(tuple(p+n*w+np.array([0,0,.04 if w==0 else 0])))
faces=[]
for i in range(N):
 j=(i+1)%N
 for s in range(2):faces.append((i*3+s,j*3+s,j*3+s+1,i*3+s+1))
road=mesh('DRIVEABLE_ROAD_8m',verts,faces,asphalt,'ROAD')
# ribbon markings
for offset,w,n in [(-3.65,.13,'Left edge stripe'),(3.65,.13,'Right edge stripe'),(0,.14,'Dashed centreline')]:
 v=[];f=[]
 for i in range(N):
  if offset==0 and int(sum(dist[:i])/4)%2:continue
  j=(i+1)%N;b=len(v)
  for k,d in [(i,offset-w/2),(j,offset-w/2),(j,offset+w/2),(i,offset+w/2)]:v.append(tuple(path[k]+normal[k]*d+[0,0,.065]))
  f.append((b,b+1,b+2,b+3))
 mesh(n,v,f,paint,'ROAD')
# start finish checkered line at inland straight near sample 700
si=690
for a in range(12):
 for b in range(2):
  k=(si+b)%N;center=path[k]+normal[k]*(-3.7+(a+.5)*7.4/12)
  ob=cube('Start finish checker',center+[0,0,.08],(.7,7.4/12,.03),paint if (a+b)%2==0 else dark,'ROAD');ob.rotation_euler[2]=math.atan2(tang[k,1],tang[k,0])
# road retaining shoulders and outer parapets follow exact road; bridge has distinct stone
for side in [-1,1]:
 v=[];f=[]
 for i,(p,n) in enumerate(zip(path,normal)):
  for off,z in [(4.05,-.3),(5.1,-.3),(5.1,.9),(4.55,.9)]:v.append(tuple(p+n*off*side+[0,0,z]))
 for i in range(N):
  j=(i+1)%N
  for q in range(3):f.append((i*4+q,j*4+q,j*4+q+1,i*4+q+1))
 ob=mesh('Continuous stone safety parapet '+str(side),v,f,stone,'ROAD')
 for p in ob.data.polygons:p.material_index=random.randrange(4)
# nearest road for land shaping excludes bridge
landpath=path[~bridge_mask]
def near(x,y):
 d=(landpath[:,0]-x)**2+(landpath[:,1]-y)**2;i=int(np.argmin(d));return math.sqrt(float(d[i])),landpath[i,2]
def coast(x):
 return float(np.interp(x,[-230,-180,-125,-80,-35,0,25,55,90,130,175,210],[-78,-100,-119,-103,-35,35,35,0,3,43,75,120]))
def terrain(x,y):
 sh=y-coast(x);main=3+42*(1-math.exp(-max(sh,0)/80))+7*sin(x*.025)*sin(y*.022)
 if sh<0:main=-3+sh*.34
 # near lighthouse promontory
 mound=28*math.exp(-((x-145)/25)**2-((y-75)/34)**2)
 main=max(main,mound-2)
 if y>165:main+=min(55,(y-165)*.55)*(0.7+0.3*sin(x*.035)**2)
 d,z=near(x,y)
 if d<6.5:return z-.35
 if d<15:return (z-.35)*(1-(d-6.5)/8.5)+main*((d-6.5)/8.5)
 return main
xs=np.linspace(-232,202,155);ys=np.linspace(-153,215,135);v=[]
for y in ys:
 for x in xs:v.append((x,y,terrain(x,y)))
f=[]
for j in range(len(ys)-1):
 for i in range(len(xs)-1):a=j*len(xs)+i;f.extend([(a,a+1,a+1+len(xs)),(a,a+1+len(xs),a+len(xs))])
land=mesh('Sculpted coastal terrain',v,f,grass+stone+[sand],'TERRAIN')
for p in land.data.polygons:
 z=sum(v[k][2] for k in p.vertices)/3;coords=np.array([v[k] for k in p.vertices]);n=np.cross(coords[1]-coords[0],coords[2]-coords[0]);slope=abs(n[2])/max(np.linalg.norm(n),.0001)
 mx=sum(v[k][0] for k in p.vertices)/3;my=sum(v[k][1] for k in p.vertices)/3
 p.material_index=8 if z<2 else (4+int(abs(sin(mx*.17+my*.1))*3.99) if slope<.78 else min(3,max(0,int(1.5+1.3*sin(mx*.025)*cos(my*.032)))))
 p.use_smooth=True
# cliff rocks along coast, reject road proximity
for q in range(240):
 x=random.uniform(-206,182);y=coast(x)+random.uniform(-6,12);d,_=near(x,y)
 if d<11:continue
 z=terrain(x,y);sz=random.uniform(3,8)
 o=ico('Stratified limestone outcrop',(x,y,max(z-4,0)),(sz*.7,sz*.6,sz*1.4),random.choice(stone),'TERRAIN',2);o.rotation_euler=(random.uniform(-.3,.3),random.uniform(-.3,.3),random.random()*pi)
# foreground hairpin central rocky crown clear of road
for q in range(18):
 x=random.uniform(-118,-88);y=random.uniform(-77,-53);d,_=near(x,y)
 if d>12:ico('Hairpin rock monolith',(x,y,terrain(x,y)+random.uniform(1,5)),(random.uniform(3,6),random.uniform(3,6),random.uniform(5,12)),random.choice(stone),'TERRAIN',2)
print('Terrain and road built',flush=True)
# Prominent rocky island in foreground hairpin, terraced accents inland.
for dx,dy,sz in [(-7,-3,11),(5,1,13),(0,7,9),(-1,-8,10)]:
 x,y=-104+dx,-66+dy;z=terrain(x,y)
 o=ico('Hairpin landmark limestone spire',(x,y,z+sz*.45),(sz*.65,sz*.6,sz),stone[1],'TERRAIN',2)
 for ve in o.data.vertices:ve.co*=random.uniform(.86,1.15)
for yy in [65,90,115]:
 for xx in range(-135,-35,5):
  if near(xx,yy)[0]>11:
   z=terrain(xx,yy);cube('Hillside terrace wall',(xx,yy,z+.6),(4.8,1,1.2),stone[1],'TERRAIN')
# actual arch bridge under road, four open semicircular vaults; deck follows exact curve
# road has gentle curve, bridge structural axis near x
for cx in [-7,10,27,44]:
 cy=float(np.interp(cx,path[400:480,0],path[400:480,1])) if False else -10+max(cx-25,0)*.12
 # arch masonry ring extruded in Y, opening radius 6.4, springline 8.5
 r=7.2;R=8.1;z0=7.0;v=[];f=[]
 for j in range(25):
  t=pi*j/24
  for yy,rr in [(-4.8,r),(4.8,r),(-4.8,R),(4.8,R)]:v.append((cx+rr*cos(t),cy+yy,z0+rr*sin(t)))
 for j in range(24):
  a=j*4;b=(j+1)*4
  f.extend([(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)])
 ob=mesh('Bridge open arch',v,f,stone,'BRIDGE')
 for p in ob.data.polygons:p.material_index=random.randrange(4)
 # solid spandrels above curved extrados to deck, no filled opening
 v=[];f=[]
 for j in range(25):
  t=pi*j/24;x=cx+R*cos(t);z=z0+R*sin(t)
  for yy,zz in [(-4.8,z),(4.8,z),(-4.8,23.5),(4.8,23.5)]:v.append((x,cy+yy,zz))
 for j in range(24):a=j*4;b=(j+1)*4;f.extend([(a,b,b+2,a+2),(a+1,a+3,b+3,b+1),(a+2,b+2,b+3,a+3)])
 mesh('Bridge stone spandrel',v,f,stone[1],'BRIDGE')
for x in [-15.5,1.5,18.5,35.5,52.5]:
 cy=-10+max(x-25,0)*.12
 cube('Bridge pier',(x,cy,11),(2.5,10.8,25),stone[1],'BRIDGE',.25)
 cube('Bridge pier coping',(x,cy,10.5),(4.1,11.2,.65),stone[0],'BRIDGE')
# water large gently undulating mesh
v=[];f=[];nw=135
for j in range(nw):
 for i in range(nw):x=-650+i*11;y=-610+j*9;v.append((x,y,-.6+.08*sin(x*.4+y*.3)+.035*sin(x*.7-y*.8)))
for j in range(nw-1):
 for i in range(nw-1):a=j*nw+i;f.append((a,a+1,a+1+nw,a+nw))
mesh('Sea surface',v,f,water,'WATER',True)
# coastal shallows as turquoise ribbons in shallow offshore area
shallow=mat('Turquoise shallows',(.015,.46,.46),.3,.1)
for q in range(50):
 x=random.uniform(-170,185);y=coast(x)-random.uniform(8,30)
 if near(x,y)[0]<12:continue
 ico('Offshore sea stack',(x,y,-1),(random.uniform(2,5),random.uniform(2,4),random.uniform(2,6)),random.choice(stone),'TERRAIN',1)
# Fine broken foam bands offshore, kept separate from driveable meshes.
for band in [4,8]:
 vv=[];ff=[]
 for i in range(200):
  x=-192+i*1.9
  if i%13>8:continue
  y=coast(x)-band;xn=x+1.9;yn=coast(xn)-band;b=len(vv)
  vv.extend([(x,y,-.42),(xn,yn,-.42),(xn,yn+.19,-.42),(x,y+.19,-.42)]);ff.append((b,b+1,b+2,b+3))
 mesh('Broken shoreline foam',vv,ff,foam,'WATER')
# tree generators reusable shapes joined later

def pine(x,y,z,s=1):
 beam('Pine trunk',(x,y,z),(x+.7*s,y,z+6*s),.36*s,trunk,'VEGETATION')
 for j in range(4):
  a=j*pi/2+.3;ex=x+cos(a)*2*s;ey=y+sin(a)*2*s
  beam('Pine branch',(x+.4*s,y,z+3.5*s),(ex,ey,z+6.6*s),.16*s,trunk,'VEGETATION')
  ico('Umbrella pine canopy',(ex,ey,z+(7+random.random())*s),(3.4*s,2.7*s,1.6*s),random.choice(leaves),'VEGETATION',2)
def cypress(x,y,z,s=1):
 cyl('Cypress trunk',(x,y,z+2*s),.25*s,4*s,trunk,'VEGETATION',7)
 for j in range(3):ico('Cypress crown',(x,y,z+(3.7+j*2.4)*s),((1.25-j*.25)*s,(1.25-j*.25)*s,3.4*s),random.choice(leaves),'VEGETATION',1)
for q in range(480):
 x=random.uniform(-206,174);y=random.uniform(-105,185);z=terrain(x,y);d,_=near(x,y)
 if z<4 or d<8 or (0<x<60 and y<30):continue
 if q%3==0:pine(x,y,z,random.uniform(.8,1.35))
 else:cypress(x,y,z,random.uniform(.55,1.1))
# shrubs and flowers foreground / path margins
flower=[mat('Bougainvillea pink',(.66,.10,.30)),mat('Golden broom',(.75,.57,.05)),mat('Wildflower lilac',(.42,.21,.43))]
for q in range(350):
 k=random.randrange(N);side=random.choice([-1,1]);p=path[k]+normal[k]*random.uniform(8,14)*side
 if bridge_mask[k]:continue
 z=terrain(p[0],p[1]);
 if z<2:continue
 ico('Mediterranean shrub',(p[0],p[1],z+.7),(1.5,1.1,.9),random.choice(leaves if q%3 else flower),'VEGETATION',1)
print('Vegetation built',flush=True)
# village buildings, roof gable with facade windows

def house(x,y,w,d,h,ang=0):
 z=terrain(x,y);body=cube('Village plaster house',(x,y,z+h/2),(w,d,h),random.choice(plaster),'VILLAGE',.12)
 v=[(-w*.58,-d*.58,0),(w*.58,-d*.58,0),(w*.58,d*.58,0),(-w*.58,d*.58,0),(-w*.58,0,h*.36),(w*.58,0,h*.36)]
 v=[(a+x,b+y,c+z+h) for a,b,c in v];mesh('Terracotta pitched roof',v,[(0,1,5,4),(4,5,2,3),(0,4,3),(1,2,5)],roof,'VILLAGE')
 for side in [-1,1]:
  for xx in [-.25,.25]:
   for zz in [.38,.72]:
    cube('Recessed window',(x+w*xx,y+side*(d/2+.06),z+h*zz),(w*.16,.12,h*.14),dark,'VILLAGE')
    for s in [-1,1]:cube('Green window shutter',(x+w*xx+s*w*.11,y+side*(d/2+.12),z+h*zz),(w*.05,.13,h*.16),wood,'VILLAGE')
 cube('Door',(x,y-d/2-.08,z+h*.15),(w*.15,.16,h*.3),trunk,'VILLAGE')
 cyl('Chimney',(x+w*.3,y+d*.2,z+h*1.25),.5,2,stone[0],'VILLAGE',4)
for x,y,w,d,h in [(89,65,9,8,10),(96,81,8,7,9),(112,86,10,8,13),(130,70,9,7,11),(137,91,8,9,12),(151,108,10,8,11),(88,111,10,7,12),(69,105,8,7,9),(146,51,9,8,10),(-148,90,11,9,12),(-72,111,12,10,12),(-126,45,9,8,10),(-40,118,9,7,10)]:
 if near(x,y)[0]>12:house(x,y,w,d,h)
# lighthouse elevated headland
lx,ly=151,77;lz=terrain(lx,ly)
cyl('Lighthouse foundation',(lx,ly,lz+1),5,2,stone[1],'VILLAGE',32)
cyl('Ivory lighthouse tower',(lx,ly,lz+15),3.1,28,plaster[2],'VILLAGE',32,r2=2.25)
cyl('Lighthouse red band',(lx,ly,lz+26),2.35,1.2,red,'VILLAGE',32)
cyl('Lighthouse balcony',(lx,ly,lz+29),3.3,.6,stone[1],'VILLAGE',32)
cyl('Lantern glazing',(lx,ly,lz+31),1.95,3.5,dark,'VILLAGE',16)
for j in range(8):a=j*pi/4;beam('Lantern mullion',(lx+1.95*cos(a),ly+1.95*sin(a),lz+29.5),(lx+1.95*cos(a),ly+1.95*sin(a),lz+32.7),.11,paint,'VILLAGE')
cyl('Lantern roof',(lx,ly,lz+33.2),2.8,1.5,red,'VILLAGE',16,r2=0)
# roadside chevrons around tight foreground bend
for k in [35,65,95,125,155,185,245,340,400]:
 p=path[k]+normal[k]*6.0;z=p[2];beam('Warning sign pole',p+[0,0,.5],p+[0,0,2.8],.09,dark,'ROAD')
 ob=cube('Chevron sign',p+[0,0,2.9],(1.25,.12,.85),paint,'ROAD');ob.rotation_euler[2]=math.atan2(tang[k,1],tang[k,0])+pi/2
# sailboats offshore
sail=mat('Canvas sail',(.94,.91,.79));hull=mat('Boat hull',(.23,.18,.12))
for x,y,s in [(180,-65,1),(265,50,1.4),(85,-110,.8),(210,140,.9)]:
 ico('Boat hull',(x,y,.1),(1.3*s,4*s,.7*s),hull,'WATER',1);beam('Mast',(x,y,.3),(x,y,11*s),.09*s,trunk,'WATER');mesh('Triangular sail',[(x,y,.8),(x,y,10*s),(x,y+4.2*s,1.3)],[(0,1,2)],sail,'WATER')
# Distant layered mountain massifs, smooth connected surface rather than spikes.
mountain_mat=mat('Distant blue limestone',(.30,.42,.46))
for x0,y0,scale in [(20,330,1),(-210,300,1),(290,310,.8)]:
 vv=[];ff=[];nx=65;ny=13
 for j in range(ny):
  yy=y0+(j-ny/2)*8
  for i in range(nx):
   xx=x0+(i-nx/2)*6
   height=(24+13*sin(i*.13)+8*sin(i*.27+.3))*max(0,1-((j-6)/6)**2)*scale
   vv.append((xx,yy,height))
 for j in range(ny-1):
  for i in range(nx-1):a=j*nx+i;ff.append((a,a+1,a+nx+1,a+nx))
 mesh('Distant layered massif',vv,ff,mountain_mat,'TERRAIN',True)
# sky clumps distant, warm light
cloud=mat('Warm ivory clouds',(.91,.90,.84),1)
for x,y,z,s in [(-170,360,160,30),(90,410,185,40),(350,300,160,35),(-350,230,135,35)]:
 for j in range(7):ico('Cumulus cloud',(x+random.uniform(-s,s),y+random.uniform(-s*.4,s*.4),z+random.uniform(-s*.3,s*.3)),(s*.8,s*.5,s*.5),cloud,'SKY',2)
for ob in cols['VEGETATION'].objects:
 if ob.type=='MESH' and ('canopy' in ob.name or 'crown' in ob.name):
  for poly in ob.data.polygons:poly.use_smooth=True
# collision road only duplicate clean identical driving surface
collision=mesh('COLLISION_ROAD',verts,faces,asphalt,'COLLISION');collision.hide_render=True
for poly in collision.data.polygons:poly.use_smooth=True
cols['COLLISION'].hide_viewport=True
print('Scene built',flush=True)
# audits geometrical
from mathutils.bvhtree import BVHTree
# nearest separation for nonlocal route samples
minsep=999
for i in range(0,N,4):
 ds=np.linalg.norm(path[:,:2]-path[i,:2],axis=1);cyclic=np.minimum((np.arange(N)-i)%N,(i-np.arange(N))%N);ds[cyclic<35]=999;minsep=min(minsep,float(ds.min()))
# road terrain clearance sample mid + edge excluding bridge
clear=[]
for i in range(0,N,4):
 if bridge_mask[i]:continue
 for off in [-4,0,4]:q=path[i]+normal[i]*off;clear.append(q[2]-terrain(q[0],q[1]))
tri=sum(len(p.vertices)-2 for c in cols.values() if c.name not in ['COLLISION','STUDIO'] for o in c.objects if o.type=='MESH' for p in o.data.polygons)
audit={'units':'meters','closed_loop':True,'road_width_m':8,'centerline_length_m':round(length,2),'max_grade_percent':round(float(grade.max()*100),2),'min_nonlocal_centerline_separation_m':round(minsep,2),'road_surface_triangles':len(faces)*2,'scene_triangles_before_export':tri,'minimum_analytical_terrain_clearance_m':round(min(clear),3),'samples':N,'collision_scope':'Road surface only. Walls and scenery are not included.','design_note':'Closed loop interpretation of single illustration; inland return invented.'}
assert minsep>9, minsep
assert grade.max()<.25
assert min(clear)>0
json.dump(audit,open(OUT+'/track_audit.json','w'),indent=2)
json.dump({'coordinate_system':'Blender Z up; GLB Y up converts [x,y,z] to [x,z,-y]','width_m':8,'closed':True,'length_m':length,'centerline_blender':[list(map(float,p)) for p in path],'centerline_gltf':[[float(p[0]),float(p[2]),float(-p[1])] for p in path],'checkpoints':[{'index':i,'position_blender':list(map(float,path[i])),'forward_blender':list(map(float,seg[i]/dist[i]))} for i in range(0,N,60)],'spawn_blender':list(map(float,path[690]+[0,0,1]))},open(OUT+'/track_route.json','w'),indent=2)
# scene lighting
sc=bpy.context.scene;sc.world.use_nodes=True;nt=sc.world.node_tree;nt.nodes.clear();bg=nt.nodes.new('ShaderNodeBackground');bg.inputs['Color'].default_value=(.34,.57,.8,1);bg.inputs['Strength'].default_value=.55;wo=nt.nodes.new('ShaderNodeOutputWorld');nt.links.new(bg.outputs[0],wo.inputs[0])
bpy.ops.object.light_add(type='SUN',location=(0,0,200));sun=bpy.context.object;sun.name='Late afternoon sun';sun.rotation_euler=(.5,-.5,-.7);sun.data.energy=3;sun.data.angle=.14;sun.data.color=(1,.83,.61);link(sun,'STUDIO')
bpy.ops.object.camera_add(location=(155,-330,155));cam=bpy.context.object;cam.name='Coastal beauty camera';cam.rotation_euler=(Vector((-20,30,21))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=430;link(cam,'STUDIO');sc.camera=cam
sc.render.engine='CYCLES';sc.cycles.samples=64;sc.cycles.use_denoising=False;sc.render.resolution_x=1600;sc.render.resolution_y=1000;sc.render.resolution_percentage=100;sc.view_settings.view_transform='AgX';sc.view_settings.look='AgX - Medium High Contrast';sc.render.image_settings.file_format='PNG'
# exports without render-only sky, camera or collision
bpy.ops.object.select_all(action='DESELECT')
for cat in ['ROAD','TERRAIN','BRIDGE','VILLAGE','VEGETATION','WATER']:
 for o in cols[cat].objects:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=OUT+'/Coastal_Circuit.glb',export_format='GLB',use_selection=True,export_apply=True)
cols['COLLISION'].hide_viewport=False;bpy.ops.object.select_all(action='DESELECT');collision.hide_set(False);collision.select_set(True);bpy.context.view_layer.objects.active=collision
bpy.ops.export_scene.gltf(filepath=OUT+'/Road_Collision.glb',export_format='GLB',use_selection=True,export_apply=True)
collision.hide_set(True);cols['COLLISION'].hide_viewport=True;bpy.ops.object.select_all(action='DESELECT')
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/Coastal_Circuit.blend')
print('AUDIT',audit,flush=True)
sc.render.filepath=OUT+'/preview_coast.png';bpy.ops.render.render(write_still=True)
cam.location=(-20,35,520);cam.rotation_euler=(0,0,0);cam.rotation_euler=(Vector((-20,35,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=480;sc.render.resolution_x=1400;sc.render.resolution_y=1200;sc.render.filepath=OUT+'/preview_layout.png';sc.cycles.samples=24;bpy.ops.render.render(write_still=True)
print('COMPLETE',flush=True)
