import bpy,os,json,struct
O=os.path.dirname(os.path.abspath(__file__));bpy.ops.wm.open_mainfile(filepath=O+'/Coastal_Circuit.blend')
export=[]
for cat in ['ROAD','TERRAIN','BRIDGE','VILLAGE','VEGETATION','WATER']:
 objs=[o for o in bpy.data.collections[cat].objects if o.type=='MESH'];bpy.ops.object.select_all(action='DESELECT')
 for o in objs:o.select_set(True)
 bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.join();ob=bpy.context.object;ob.name=cat+'_STATIC_BATCH';export.append(ob)
bpy.ops.object.select_all(action='DESELECT')
for o in export:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=O+'/Coastal_Circuit.glb',export_format='GLB',use_selection=True,export_apply=True)
b=open(O+'/Coastal_Circuit.glb','rb').read();n,t=struct.unpack_from('<II',b,12);g=json.loads(b[20:20+n]);a={'mesh_count':len(g['meshes']),'primitive_count':sum(len(m['primitives']) for m in g['meshes']),'triangles':sum(g['accessors'][p['indices']]['count']//3 for m in g['meshes'] for p in m['primitives'])};json.dump(a,open(O+'/export_optimization.json','w'),indent=2);print(a)
