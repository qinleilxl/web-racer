import bpy,json,os,math,struct
from mathutils import Vector
from mathutils.bvhtree import BVHTree
O=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=O+'/Coastal_Circuit.blend')
route=json.load(open(O+'/track_route.json'));p=route['centerline_blender'];land=bpy.data.objects['Sculpted coastal terrain'];deps=bpy.context.evaluated_depsgraph_get();bv=BVHTree.FromObject(land,deps)
clear=[];bad=[]
for i,q in enumerate(p):
 if -16<q[0]<59 and -18<q[1]<4:continue
 p0=Vector(p[(i-1)%len(p)]);p1=Vector(p[(i+1)%len(p)]);t=(p1-p0);n=Vector((-t.y,t.x,0)).normalized()
 for off in [-3.9,0,3.9]:
  v=Vector(q)+off*n;hit=bv.ray_cast(v+Vector((0,0,300)),Vector((0,0,-1)),600)[0]
  if hit:
   c=v.z-hit.z;clear.append(c)
   if c<-.02:bad.append([i,off,c])
res={'actual_terrain_clearance_min_m':min(clear),'buried_road_samples':len(bad),'worst_buried':sorted(bad,key=lambda x:x[2])[:10]}
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=O+'/Road_Collision.glb');objs=[o for o in bpy.context.scene.objects if o.type=='MESH'];res['collision_reimport_triangles']=sum(len(f.vertices)-2 for o in objs for f in o.data.polygons)
# edge use count: closed strip has 2 boundary loops, no seam across circuit
me=objs[0].data;edges={}
for f in me.polygons:
 for i,a in enumerate(f.vertices):b=f.vertices[(i+1)%len(f.vertices)];k=tuple(sorted((a,b)));edges[k]=edges.get(k,0)+1
res['collision_boundary_edges']=sum(v==1 for v in edges.values());res['nonmanifold_branch_edges']=sum(v>2 for v in edges.values())
adj={}
for (a,b),count in edges.items():
 if count==1:adj.setdefault(a,[]).append(b);adj.setdefault(b,[]).append(a)
seen=set();loops=0
for start in adj:
 if start in seen:continue
 loops+=1;stack=[start]
 while stack:
  v=stack.pop()
  if v in seen:continue
  seen.add(v);stack.extend(adj[v])
res['collision_boundary_loops']=loops
assert loops==2 and all(len(ns)==2 for ns in adj.values())
assert not bad and res['collision_reimport_triangles']==3840

for name in ['Coastal_Circuit.glb','Road_Collision.glb']:
 b=open(O+'/'+name,'rb').read();l,typ=struct.unpack_from('<II',b,12);g=json.loads(b[20:20+l]);tris=sum(g['accessors'][p['indices']]['count']//3 for m in g['meshes'] for p in m['primitives']);res[name+'_triangles']=tris
json.dump(res,open(O+'/validation_results.json','w'),indent=2);print(res)
