import bpy,os
from mathutils import Vector
O=os.path.dirname(os.path.abspath(__file__));bpy.ops.wm.open_mainfile(filepath=O+'/Coastal_Circuit.blend');s=bpy.context.scene;c=s.camera
for o in bpy.data.collections['SKY'].objects:o.hide_render=True
c.location=(-115,-185,82);c.rotation_euler=(Vector((35,20,25))-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='PERSP';c.data.lens=36
s.render.resolution_x=1600;s.render.resolution_y=1000;s.cycles.samples=64;s.render.filepath=O+'/preview_hairpin.png';bpy.ops.render.render(write_still=True)
