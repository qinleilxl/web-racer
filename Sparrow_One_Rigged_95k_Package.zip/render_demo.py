import bpy,os,math
from mathutils import Vector
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT,'Sparrow_One_Rigged.blend'))
scene=bpy.context.scene;ctrl=bpy.data.objects['CAR_CONTROLS'];ctrl.animation_data_create();ctrl.animation_data.action=bpy.data.actions['DEMO_CONTROLS']
root=bpy.data.objects['CAR_ROOT'];root.location.z=.18
scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False
scene.render.resolution_x=800;scene.render.resolution_y=600;scene.render.resolution_percentage=100
scene.render.fps=12;scene.frame_start=1;scene.frame_end=72;scene.render.image_settings.file_format='PNG'
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.10
for name,power in [('Key',500),('Fill',270),('Rim',450)]:bpy.data.objects[name].data.energy=power
cam=scene.camera;cam.location=(-4.8,-5,2.45);cam.data.ortho_scale=4.6;cam.rotation_euler=(Vector((0,0,1.05))-cam.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.light_add(type='POINT', location=(.30,-.05,1.70))
interior=bpy.context.object;interior.name='Demo cabin fill';interior.data.energy=12;interior.data.shadow_soft_size=.15
# Fixed exterior shot followed by a close cockpit view to show the steering-wheel linkage.
for frame in range(1,73):
 scene.frame_set(frame)
 if frame<=48:
  cam.data.type='ORTHO';cam.location=(-4.8,-5,2.45);cam.data.ortho_scale=4.6;target=Vector((0,0,1.05));interior.data.energy=0
 else:
  cam.data.type='PERSP';cam.data.lens=30;cam.data.clip_start=.01;cam.location=(.42,-.31,1.64);target=Vector((-.08,-.29,1.43));interior.data.energy=12
 cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
 scene.render.filepath=os.path.join(OUT,'frames','%04d.png'%frame)
 bpy.ops.render.render(write_still=True)
