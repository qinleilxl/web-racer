import bpy, math, os, json, shutil
from mathutils import Vector, Matrix
from math import sin,cos,pi
OUT=os.path.dirname(os.path.abspath(__file__)); SRC=os.path.join(OUT,'source','base_model.blend')
bpy.ops.wm.open_mainfile(filepath=SRC)
car=bpy.data.collections['SPARROW • vehicle'];root=next(o for o in car.objects if o.type=='EMPTY');root.name='CAR_ROOT'
steel=bpy.data.materials['Warm aged steel'];red=bpy.data.materials['Faded terracotta roof'];black=bpy.data.materials['Recesses']
def parent(o,p):
 bpy.context.view_layer.update()
 m=o.matrix_world.copy();o.parent=p;o.matrix_world=m

def empty(name,loc,parent_obj=root):
 o=bpy.data.objects.new(name,None);car.objects.link(o);o.location=loc;o.empty_display_type='PLAIN_AXES';o.empty_display_size=.10
 if parent_obj:parent(o,parent_obj)
 return o
ctrl=empty('CAR_CONTROLS',(0,0,2));ctrl.empty_display_type='CUBE';ctrl.empty_display_size=.15
props={'steer_deg':(0,-28,28,'Positive = left steering. Linked steering wheel ratio 12:1.'),'wheel_roll_deg':(0,-100000,100000,'Positive roll travels toward front (-X), rotates around local -Y.'),'headlights':(0,0,1,'0 off, 1 on. Drives emissive lenses and actual spot lights.'),'suspension_FL':(0,-.09,.045,'Wheel vertical offset in meters. Positive compression.'),'suspension_FR':(0,-.09,.045,'Wheel vertical offset in meters. Positive compression.'),'suspension_RL':(0,-.09,.045,'Wheel vertical offset in meters. Positive compression.'),'suspension_RR':(0,-.09,.045,'Wheel vertical offset in meters. Positive compression.')}
for k,(v,lo,hi,desc) in props.items():ctrl[k]=float(v);ctrl.id_properties_ui(k).update(min=lo,max=hi,soft_min=lo,soft_max=hi,description=desc)
def driver(owner,path,index,prop,expr):
 fc=owner.driver_add(path,index) if index is not None else owner.driver_add(path);d=fc.driver;d.type='SCRIPTED';v=d.variables.new();v.name='v';v.type='SINGLE_PROP';v.targets[0].id=ctrl;v.targets[0].data_path='["'+prop+'"]';d.expression=expr
 return fc

def center(o):return sum((o.matrix_world@Vector(c) for c in o.bound_box),Vector())/8
wheel_prefix=['Tire casing','Chevron tire tread','Sidewall molded shoulder','Wheel barrel','Rolled steel rim lip','Pressed concave steel wheel','Wheel ventilation recess','Domed hubcap','Wheel lug']
parts={};pivots=[]
for x,front in [(-1.07,True),(1.02,False)]:
 for s in [-1,1]:
  tag=('F' if front else 'R')+('L' if s<0 else 'R');base=(x,s*.735,.435)
  sus=empty('SUSP_'+tag,base);driver(sus,'location',2,'suspension_'+tag,'.435+v');pivots.append(sus)
  steer=empty('STEER_'+tag,base,sus);pivots.append(steer)
  if front:driver(steer,'rotation_euler',2,'steer_deg','v*pi/180')
  spin=empty('ROLL_'+tag,base,steer);driver(spin,'rotation_euler',1,'wheel_roll_deg','-v*pi/180');pivots.append(spin)
  group=[]
  for o in list(car.objects):
   if o.type=='MESH' and any(o.name.startswith(p) for p in wheel_prefix):
    c=center(o)
    if abs(c.x-x)<.35 and (c.y*s)>0:parent(o,spin);group.append(o.name)
  parts[tag]={'suspension':sus,'steer':steer,'spin':spin,'meshes':group}
# Replace rigid static suspension decoration with articulated mounts and stretchable links.
for o in list(car.objects):
 if any(o.name.startswith(p) for p in ['Suspension damper','Terracotta coil spring','Wishbone','Axle housing']):bpy.data.objects.remove(o,do_unlink=True)
def mesh(name,verts,faces,mat):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);car.objects.link(o);o.data.materials.append(mat)
 for p in me.polygons:p.use_smooth=True
 return o

def cylinder_unit(name,r,mat,n=20):
 v=[(r*cos(2*pi*j/n),r*sin(2*pi*j/n),z) for z in [0,1] for j in range(n)];f=[]
 for j in range(n):f.append((j,(j+1)%n,(j+1)%n+n,j+n))
 f.extend([tuple(reversed(range(n))),tuple(range(n,2*n))]);return mesh(name,v,f,mat)
links=[]
def stretch(o,a,target,rest=1,negative=False):
 o.location=a;parent(o,root);con=o.constraints.new('DAMPED_TRACK');con.target=target;con.track_axis='TRACK_NEGATIVE_Z' if negative else 'TRACK_Z'
 fc=o.driver_add('scale',2);d=fc.driver;v=d.variables.new();v.name='dist';v.type='LOC_DIFF';v.targets[0].id=o;v.targets[1].id=target;d.expression='dist/'+str(rest);links.append(o)
for tag,data in parts.items():
 sus=data['suspension'];x=sus.location.x;s=1 if sus.location.y>0 else -1
 lower=empty('LOWER_SHOCK_'+tag,(x,s*.52,.43),sus)
 # Fixed top mount; coil compresses around moving damper, not translated wholesale.
 vv=[];ff=[];N=96;K=6;length=.30
 for i in range(N+1):
  t=i/N;ang=t*12*pi
  for j in range(K):
   b=2*pi*j/K;rr=.048+.008*cos(b);vv.append((rr*cos(ang),rr*sin(ang),-length*t+.008*sin(b)))
 for i in range(N):
  for j in range(K):a=i*K+j;b=i*K+(j+1)%K;ff.append((a,b,b+K,a+K))
 coil=mesh('COIL_'+tag,vv,ff,red);stretch(coil,(x,s*.52,.73),lower,.30,True)
 damper=cylinder_unit('DAMPER_'+tag,.016,steel);stretch(damper,(x,s*.52,.73),lower)
 shaft=cylinder_unit('HALF_SHAFT_'+tag,.026,steel);stretch(shaft,(x,0,.435),sus)
 arm=cylinder_unit('CONTROL_ARM_'+tag,.018,steel);stretch(arm,(x-.20,s*.23,.40),lower)
# Replace steering wheel geometry with a properly axial ring/spokes.
for o in list(car.objects):
 if o.name.startswith('Bakelite steering wheel') or o.name.startswith('Steering spoke'):bpy.data.objects.remove(o,do_unlink=True)
sw=empty('STEERING_WHEEL_PIVOT',(-.06,-.29,1.2646));sw.rotation_mode='XYZ';sw.rotation_euler=Vector((.32,0,.1554)).to_track_quat('Z','Y').to_euler();driver(sw,'rotation_euler',2,'steer_deg','-v*pi/180*12')
# Driver on local Euler Z after a fixed orientation would not spin along its own tilted normal.
# Use a separate orientation mount and child local spin pivot.
sw.driver_remove('rotation_euler',2); mount=empty('STEERING_COLUMN_FRAME',tuple(sw.location));mount.rotation_euler=sw.rotation_euler.copy();parent(sw,mount);sw.rotation_euler=(0,0,0);driver(sw,'rotation_euler',2,'steer_deg','-v*pi/180*12');pivots.append(sw)
v=[];f=[]
for i in range(48):
 a=2*pi*i/48
 for j in range(8):b=2*pi*j/8;rr=.145+.011*cos(b);v.append((rr*cos(a),rr*sin(a),.011*sin(b)))
for i in range(48):
 for j in range(8):f.append((i*8+j,i*8+(j+1)%8,((i+1)%48)*8+(j+1)%8,((i+1)%48)*8+j))
o=mesh('Steering wheel ring',v,f,black);o.parent=sw
for i in range(3):
 a=2*pi*i/3;o=cylinder_unit('Steering wheel spoke '+str(i),.005,steel,12);o.parent=sw;o.rotation_euler=Vector((cos(a),sin(a),0)).to_track_quat('Z','Y').to_euler();o.scale.z=.135
# Lights, emissive lenses and actual projected beams.
lamp=bpy.data.materials['Headlight prismatic glass'];node=lamp.node_tree.nodes.get('Principled BSDF');driver(node.inputs['Emission Strength'],'default_value',None,'headlights','v*12')
light_objs=[]
for s in [-1,1]:
 dat=bpy.data.lights.new('Headlight beam '+str(s),'SPOT');dat.energy=0;dat.color=(1,.77,.43);dat.spot_size=math.radians(68);dat.spot_blend=.35;dat.shadow_soft_size=.06
 o=bpy.data.objects.new('HEADLIGHT_'+('L' if s<0 else 'R'),dat);car.objects.link(o);o.location=(-1.72,s*.525,1.02);o.rotation_euler=Vector((-1,0,-.15)).to_track_quat('-Z','Y').to_euler();parent(o,root);driver(dat,'energy',None,'headlights','v*450');light_objs.append(o)
# Validate live rig controls before baking.
def setprops(**kw):
 for k,v in kw.items():ctrl[k]=v
 ctrl.update_tag();bpy.context.view_layer.update();bpy.context.scene.frame_set(bpy.context.scene.frame_current)
def evalmat(o):return o.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world.copy()
setprops(steer_deg=20,wheel_roll_deg=90,suspension_FL=.04,headlights=1)
assert abs(parts['FL']['suspension'].location.z-.475)<1e-5
assert abs(parts['FL']['steer'].rotation_euler.z-math.radians(20))<1e-5
assert abs(parts['FL']['spin'].rotation_euler.y+pi/2)<1e-5
assert abs(sw.rotation_euler.z+math.radians(240))<1e-5
assert abs(light_objs[0].data.energy-450)<1e-5
assert abs(node.inputs['Emission Strength'].default_value-12)<1e-5
setprops(steer_deg=0,wheel_roll_deg=0,suspension_FL=0,headlights=0)
# Demo in editable Blender: property animation only, controls remain intact.
scene=bpy.context.scene;scene.render.fps=12;scene.frame_start=1;scene.frame_end=72
for frame in range(1,73):
 t=(frame-1)/71;ctrl['steer_deg']=26*sin(2*pi*t);ctrl['wheel_roll_deg']=t*720;ctrl['headlights']=1.0 if frame>=25 else 0.0
 for j,tag in enumerate(parts):ctrl['suspension_'+tag]=-.025+.065*sin(4*pi*t+j*pi/2)
 for k in props:ctrl.keyframe_insert(data_path='["'+k+'"]',frame=frame)
ctrl.animation_data.action.name='DEMO_CONTROLS';ctrl.animation_data.action.use_fake_user=True
for fc in ctrl.animation_data.action.fcurves:
 for key in fc.keyframe_points:key.interpolation='CONSTANT' if 'headlights' in fc.data_path else 'LINEAR'
scene.frame_set(1)
ctrl.animation_data.action=None
setprops(**{k:0.0 for k in props})
# Default workspace shows a useful perspective and controls selected.
bpy.ops.object.select_all(action='DESELECT');ctrl.select_set(True);bpy.context.view_layer.objects.active=ctrl
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='PROPERTIES':area.spaces.active.context='OBJECT'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'Sparrow_One_Rigged.blend'))
# Capture clean transform clips from evaluated live constraints/drivers.
ctrl.animation_data_clear();animated=pivots+links
clips={}
for name in ['Drive','Steering','Suspension','Combined']:
 frames=[]
 for frame in range(1,49):
  t=(frame-1)/47
  values={k:0.0 for k in props};values['headlights']=1
  if name in ['Drive','Combined']:values['wheel_roll_deg']=t*720
  if name in ['Steering','Combined']:values['steer_deg']=26*sin(2*pi*t)
  if name in ['Suspension','Combined']:
   for j,tag in enumerate(parts):values['suspension_'+tag]=-.025+.065*sin(2*pi*t+j*pi/2)
  setprops(**values);dg=bpy.context.evaluated_depsgraph_get();state={}
  for o in animated:
   ev=o.evaluated_get(dg);m=ev.matrix_world.copy()
   if o.parent:m=o.parent.evaluated_get(dg).matrix_world.inverted()@m
   state[o.name]=m.decompose()
  frames.append(state)
 clips[name]=frames
# Remove procedural drivers and constraints only in export working state.
for o in animated:
 o.animation_data_clear()
 for c in list(o.constraints):o.constraints.remove(c)
 o.rotation_mode='QUATERNION'
for name,frames in clips.items():
 for o in animated:
  action=bpy.data.actions.new(name+'__'+o.name);o.animation_data_create();o.animation_data.action=action
  for frame,state in enumerate(frames,1):
   loc,rot,scale=state[o.name];o.location=loc;o.rotation_quaternion=rot;o.scale=scale
   for path in ['location','rotation_quaternion','scale']:o.keyframe_insert(data_path=path,frame=frame)
  for fc in action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
  track=o.animation_data.nla_tracks.new();track.name=name;track.strips.new(name,1,action);o.animation_data.action=None
# Restore rest pose without animated NLA evaluating before export.
for o in animated:
 for track in o.animation_data.nla_tracks:track.mute=True
setprops(**{k:0.0 for k in props});ctrl['headlights']=1;ctrl.update_tag();bpy.context.view_layer.update()
# NLA tracks must be unmuted for glTF grouping.
for o in animated:
 for tr in o.animation_data.nla_tracks:tr.mute=False
scene.frame_start=1;scene.frame_end=48
bpy.ops.object.select_all(action='DESELECT')
for o in car.objects:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'Sparrow_One_Animated.glb'),export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='NLA_TRACKS',export_force_sampling=True,export_frame_range=True,export_lights=True,export_extras=True)
# Count actual vehicle geometry.
tri=0;polys=0
for o in car.objects:
 if o.type=='MESH':o.data.calc_loop_triangles();tri+=len(o.data.loop_triangles);polys+=len(o.data.polygons)
assert 50000<=tri<=100000,tri
json.dump({'triangles':tri,'polygons':polys,'live_control_tests':'passed: steering, roll, independent travel, steering wheel linkage, emissions, projected light energy','suspension_travel_m':[-.09,.045],'steering_range_degrees':[-28,28],'steering_wheel_ratio':12,'wheel_mapping':{k:v['meshes'] for k,v in parts.items()},'clips':list(clips),'lights_note':'Blender live toggle; exported GLB lights/emission static on, runtime switching required.'},open(os.path.join(OUT,'rig_audit.json'),'w'),indent=2)
print('RIG_READY',tri,polys,flush=True)
