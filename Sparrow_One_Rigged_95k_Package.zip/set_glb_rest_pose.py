import bpy,os,json,struct
from mathutils import Matrix
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT,'Sparrow_One_Rigged.blend'))
bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();rest={}
for o in bpy.data.objects:
 if o.name.startswith(('SUSP_','STEER_','ROLL_','COIL_','DAMPER_','HALF_SHAFT_','CONTROL_ARM_')) or o.name=='STEERING_WHEEL_PIVOT':
  m=o.evaluated_get(dg).matrix_world.copy()
  if o.parent:m=o.parent.evaluated_get(dg).matrix_world.inverted()@m
  t,q,s=m.decompose();rest[o.name]={'translation':[t.x,t.z,-t.y],'rotation':[q.x,q.z,-q.y,q.w],'scale':[s.x,s.z,s.y]}
p=os.path.join(OUT,'Sparrow_One_Animated.glb');data=open(p,'rb').read();n,kind=struct.unpack_from('<II',data,12);j=json.loads(data[20:20+n]);tail=data[20+n:]
for node in j['nodes']:
 if node.get('name') in rest:node.pop('matrix',None);node.update(rest[node['name']])
js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
open(p,'wb').write(struct.pack('<4sII',b'glTF',2,12+8+len(js)+len(tail))+struct.pack('<II',len(js),0x4E4F534A)+js+tail)
print('Neutral rest pose restored for',len(rest),'animated nodes; all animation buffers preserved.')
