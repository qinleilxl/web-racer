Sparrow One 可动模型 · Blender / GLB

新增功能
1. 四轮绕各自轮心滚动；前轮可转向，后轮保持直行。
2. 四轮独立上下行程；弹簧固定上支点，随下支点压缩/伸长。
   减振杆、半轴和控制臂跟随轮心位置转动/伸缩，不再是静态装饰。
3. 方向盘与前轮转向联动，传动比为 12:1。
4. 前灯可以关闭/点亮，既有镜片发光，也有实际向前投射的聚光灯。

Blender 手动操作
打开 Sparrow_One_Rigged.blend，默认中性姿态，没有正在播放的控制动画。
选中 CAR_CONTROLS，进入 Object Properties → Custom Properties：
- steer_deg：前轮转向角（-28°～28°）；正值向车辆左侧。
- wheel_roll_deg：四轮滚动角度；正值代表朝车头方向滚动。
- suspension_FL / FR / RL / RR：对应前左、前右、后左、后右。
  单位米，范围 -0.09～+0.045；正值压缩，负值下垂。
- headlights：0 关闭，1 点亮；也支持 0～1 中间值调光。
这些属性带驱动器，方向盘和弹簧等会自动跟随。

Blender 动画演示
选择 CAR_CONTROLS，在 Dope Sheet → Action Editor 中选择 DEMO_CONTROLS，
播放第 1～72 帧（12 fps）。返回手动控制时，取消当前 Action 关联。
随附 demo_motion.mp4 为真实模型渲染：前 4 秒是举升测试姿态，后 2 秒是驾驶舱。
演示为方便观察悬挂而把车身抬高 0.18 m，因此轮胎不始终接触地面。
这是运动学模型，不是物理仿真，也没有自动轮胎地面约束、碰撞或真实弹簧动力学。

GLB 动画
Sparrow_One_Animated.glb 保留独立层级，包含 4 个烘焙动画片段：
- Drive：原地轮胎滚动两圈，车身不平移。
- Steering：前轮左右转向与方向盘联动。
- Suspension：四轮错相上下运动，弹簧/连杆跟随。
- Combined：组合演示。
每个片段约 3.92 秒。建议分别播放，避免不同片段重复控制相同节点。
FL / FR / RL / RR 的命名沿用车辆自身左右，非观看者左右。
默认静态节点为中性姿态。

GLB 车灯
导出带 KHR_lights_punctual 的两盏聚光灯，以及发光材质。
GLB 中车灯默认点亮；是否显示真实灯光取决于查看器是否支持该扩展。
Blender 自定义属性/驱动器不会变成 GLB 中可点击的开关；开关必须在运行时实现。
在 Three.js / Babylon.js / 游戏引擎中切换 HEADLIGHT_L / HEADLIGHT_R 的可见性或强度，
并同时调整 Headlight prismatic glass 材质的 emissive 强度。
GLB 不包含车灯开关动画。发光外观与实际照明需要分别控制。

坐标与层级
Blender：米，Z 向上，车头 -X。
GLB：标准 Y 向上；导出轴变换由 glTF 导出器处理。
CAR_ROOT
  SUSP_FL/FR/RL/RR：悬挂上下支点
    STEER_FL/FR/RL/RR：转向枢轴
      ROLL_FL/FR/RL/RR：轮胎滚动枢轴，轮胎/轮毂/螺栓完整附属
  STEERING_COLUMN_FRAME → STEERING_WHEEL_PIVOT
  COIL_* / DAMPER_* / HALF_SHAFT_* / CONTROL_ARM_*
Blender 中前轮转向绕本地 Z、滚动绕本地 Y；悬挂沿 Z 平移。
方向盘在倾斜的方向柱参考系内绕本地 Z 旋转。
不要直接套用 Blender 轴名到 GLB；GLB 转向轴是本地 Y，滚动轴是本地 Z。

文件
- Sparrow_One_Rigged.blend：主编辑文件，手动控制 + 保存的演示 Action。
- Sparrow_One_Animated.glb：实时运行用独立部件和动画片段。
- demo_motion.mp4：可动及灯光演示。
- rig_audit.json / validation_results.json：面数、动画和测试记录。
- rig_car.py：构建可动层级、控制和烘焙片段。
- set_glb_rest_pose.py：将 GLB 默认姿态恢复为中性，保留所有动画。
- validate_rig.py：校验实际轮心、弹簧端点、控制值和 GLB 再导入。
- render_demo.py：渲染演示帧。
- source/base_model.blend：用于重新构建的原静态模型。

重建顺序（Blender 4.3）
blender -b --python rig_car.py
blender -b --python set_glb_rest_pose.py
blender -b --python validate_rig.py
blender -b --python render_demo.py

其他限制
外观仍是参考图的几何近似，内饰简化。未制作精确底盘工程机构或可打印封闭实体。
基础 PBR 材质可用于 GLB；Blender 程序化微表面未烘焙为贴图。
