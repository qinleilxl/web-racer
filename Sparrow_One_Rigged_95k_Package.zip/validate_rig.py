import bpy,json,os,math
from mathutils import Vector
p=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(p,'Sparrow_One_Rigged.blend'))
c=bpy.data.objects['CAR_CONTROLS'];assert c.animation_data is None or c.animation_data.action is None
results={}
def update():c.update_tag();bpy.context.view_layer.update();bpy.context.scene.frame_set(1)
for side in ['FL','FR','RL','RR']:
 o=bpy.data.objects['SUSP_'+side]
 for val in [-.09,.045]:
  c['suspension_'+side]=val;update();assert abs(o.location.z-(.435+val))<1e-5
 c['suspension_'+side]=0;update()
 wheel=bpy.data.objects['Tire casing '+('0' if side[0]=='F' else '1')+' '+('-1' if side[1]=='L' else '1')]
 ctr=sum((wheel.matrix_world @ Vector(v) for v in wheel.bound_box),Vector())/8
 expected=Vector((-1.07 if side[0]=='F' else 1.02,-.735 if side[1]=='L' else .735,.435))
 assert (ctr-expected).length<.002,(side,tuple(ctr),tuple(expected))
 # Coil bottom ring follows the moving lower mount while its upper origin remains fixed.
 coil=bpy.data.objects['COIL_'+side];target=bpy.data.objects['LOWER_SHOCK_'+side]
 dg=bpy.context.evaluated_depsgraph_get();ev=coil.evaluated_get(dg)
 endpoint=ev.matrix_world @ Vector((0,0,-.30));actual=target.evaluated_get(dg).matrix_world.translation
 assert (endpoint-actual).length<.002,(side,'spring endpoint mismatch')
 results[side]='independent travel, wheel-center pivot and spring attachment passed'
for val in [-28,0,28]:
 c['steer_deg']=val;update()
 for tag in ['FL','FR']:assert abs(bpy.data.objects['STEER_'+tag].rotation_euler.z-math.radians(val))<1e-5
 assert abs(bpy.data.objects['STEERING_WHEEL_PIVOT'].rotation_euler.z+math.radians(val)*12)<1e-5
for val in [0,1]:
 c['headlights']=val;update();assert abs(bpy.data.objects['HEADLIGHT_L'].data.energy-val*450)<1e-5
results['steering']='front wheel + 12:1 steering-wheel linkage passed';results['lights']='off/on energy 0/450 W passed'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=os.path.join(p,'Sparrow_One_Animated.glb'))
tri=sum(len(o.data.polygons) for o in bpy.context.scene.objects if o.type=='MESH');assert 50000<=tri<=100000
results['reimport_triangles']=tri;results['reimport_actions']=len(bpy.data.actions)
json.dump(results,open(os.path.join(p,'validation_results.json'),'w'),indent=2);print('VALIDATED',results)
