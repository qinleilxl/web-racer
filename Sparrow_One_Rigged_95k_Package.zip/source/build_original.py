import bpy, math, os, json, random
from mathutils import Vector
from math import sin,cos,pi,sqrt
random.seed(22)
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
car=bpy.data.collections.new('SPARROW • vehicle'); bpy.context.scene.collection.children.link(car)
def movecol(o):
 for c in list(o.users_collection): c.objects.unlink(o)
 car.objects.link(o); return o
def mat(name,color,metal=0,rough=.4):
 m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*color,1); p.inputs['Metallic'].default_value=metal; p.inputs['Roughness'].default_value=rough
 return m
def worn(m,scale,strength):
 n=m.node_tree.nodes; l=m.node_tree.links; p=n.get('Principled BSDF'); noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=scale;noise.inputs['Detail'].default_value=3
 bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=strength;bump.inputs['Distance'].default_value=.008;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],p.inputs['Normal'])
cream=mat('Warm ivory enamel',(0.72,.65,.46),.2,.32); worn(cream,105,.14)
red=mat('Faded terracotta roof',(.30,.052,.028),.17,.34);worn(red,90,.1)
rubber=mat('Tire rubber',(.026,.029,.027),0,.87);worn(rubber,85,.35)
steel=mat('Warm aged steel',(.31,.29,.24),.8,.32);chrome=mat('Satin chrome',(.56,.58,.55),.88,.22);black=mat('Recesses',(.015,.019,.017),.1,.65)
leather=mat('Tobacco upholstery',(.19,.09,.039),0,.65);worn(leather,65,.2)
glass=mat('Clear warm glass',(.72,.8,.77),0,.08);p=glass.node_tree.nodes.get('Principled BSDF');p.inputs['Transmission Weight'].default_value=1;p.inputs['IOR'].default_value=1.45
amber=mat('Amber lenses',(.8,.25,.025),.15,.2);lamp=mat('Headlight prismatic glass',(.91,.73,.39),.12,.15);tail=mat('Ruby lenses',(.56,.025,.009),.1,.21)
for m,c,s in [(lamp,(1,.7,.32),.25),(tail,(.8,.02,.005),.15)]:
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=s

def mesh(name,v,f,m,smooth=True):
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);car.objects.link(o);o.data.materials.append(m)
 if smooth:
  for p in me.polygons:p.use_smooth=True
 return o

def bevel(o,w=.02,seg=3):
 mod=o.modifiers.new('Machined edge radii','BEVEL');mod.width=w;mod.segments=seg
 return o

def uv(name,loc,scale,m,seg=32,rings=16):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=seg,ring_count=rings,location=loc);o=movecol(bpy.context.object);o.name=name;o.scale=scale;o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 return o

def cube(name,loc,scale,m,b=.02):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=movecol(bpy.context.object);o.name=name;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if b:bevel(o,b,3)
 return o

def tube(name,pts,r,m,res=8,cyclic=False):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.bevel_resolution=2;sp=cu.splines.new('POLY');sp.points.add(len(pts)-1)
 for p,co in zip(sp.points,pts):p.co=(*co,1)
 sp.use_cyclic_u=cyclic;o=bpy.data.objects.new(name,cu);car.objects.link(o);o.data.materials.append(m);return o

def cyl(name,a,b,r,m,n=32):
 d=Vector(b)-Vector(a);mid=(Vector(a)+Vector(b))/2;bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=d.length,location=mid);o=movecol(bpy.context.object);o.name=name;o.rotation_euler=d.to_track_quat('Z','Y').to_euler();o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 bevel(o,.005,2);return o

def tor(name,loc,major,minor,m,axis='Y',n=64,k=12):
 bpy.ops.mesh.primitive_torus_add(major_segments=n,minor_segments=k,location=loc,major_radius=major,minor_radius=minor);o=movecol(bpy.context.object);o.name=name
 if axis=='Y':o.rotation_euler[0]=pi/2
 if axis=='X':o.rotation_euler[1]=pi/2
 o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 return o
# Smooth rounded coachwork loft; wheel tunnels are physical apertures.
xs=[-1.64+i*3.24/80 for i in range(81)];v=[];f=[]
for x in xs:
 cap=max(.05,1-(abs(x)/1.73)**8);w=.70*cap**.30
 top=1.025+.09*math.exp(-((x+1.1)/.35)**2)+.085*math.exp(-((x-1.05)/.38)**2)
 for j in range(64):
  a=2*pi*j/64; y=w*math.copysign(abs(sin(a))**.65,sin(a)); z=.78+(top-.78)*cos(a) if cos(a)>0 else .78+.30*cos(a)
  v.append((x,y,z))
for i in range(80):
 for j in range(64):a=i*64+j;b=i*64+(j+1)%64;f.append((a,b,b+64,a+64))
f.extend([tuple(reversed(range(64))),tuple(80*64+j for j in range(64))]);body=mesh('Ivory monocoque with open wheel wells',v,f,cream)
for x in [-1.07,1.02]:
 bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=.495,depth=2.2,location=(x,0,.44),rotation=(pi/2,0,0));cut=bpy.context.object
 bpy.context.view_layer.objects.active=body;mod=body.modifiers.new('Wheel arch tunnel','BOOLEAN');mod.operation='DIFFERENCE';mod.object=cut;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cut,do_unlink=True)
bevel(body,.012,2)
# Fender lips follow the actual apertures and flare outward.
for x in [-1.07,1.02]:
 for side in [-1,1]:
  vv=[];ff=[]
  for i in range(49):
   a=-.10+(pi+.20)*i/48
   for j in range(5):
    r=.493+j*.014;vv.append((x+r*cos(a),side*(.696+.035*sin(pi*j/4)),.44+r*sin(a)))
  for i in range(48):
   for j in range(4):a=i*5+j;ff.append((a,a+1,a+6,a+5))
  mesh('Rolled flared wheel arch',vv,ff,cream)
# Hood perimeter and center character line.
for side in [-1,1]:
 tube('Bonnet panel gap',[(-1.57,side*.39,.978),(-1.38,side*.44,1.025),(-.95,side*.44,1.046),(-.61,side*.46,1.005)],.005,black)
# rounded rectangular boundary, with quadratic corner interpolation
def rounded(points,steps=6,amount=.10):
 out=[]
 for i,p in enumerate(points):
  p=Vector(p); prev=Vector(points[i-1]); nex=Vector(points[(i+1)%len(points)]);a=p+(prev-p)*amount;b=p+(nex-p)*amount
  for k in range(steps):t=k/steps;out.append(tuple((1-t)**2*a+2*t*(1-t)*p+t*t*b))
 return out
# Cabin glazing with visible solid rubber and terracotta frames.
front=[(-.64,-.59,1.07),(-.64,.59,1.07),(-.24,.52,1.79),(-.24,-.52,1.79)]
rear=[(1.00,.57,1.08),(1.00,-.57,1.08),(.63,-.49,1.78),(.63,.49,1.78)]
for name,pts in [('Windscreen',front),('Rear window',rear)]:
 boundary=rounded(pts,8,.12);o=mesh(name,boundary,[tuple(range(len(boundary)))],glass,False);sol=o.modifiers.new('Glass thickness','SOLIDIFY');sol.thickness=.004
 tube(name+' rubber seal',boundary,.026,black,cyclic=True);tube(name+' chrome bead',boundary,.011,chrome,cyclic=True)
# Curved metal brow closes the space between the domed roof and glazing.
for rearward in [False,True]:
 vv=[];ff=[]
 for j in range(33):
  a=-1+2*j/32
  if not rearward:
   vv.extend([(-.24,a*.52,1.79),(-.29,a*.53,1.80+.12*(1-a*a))])
  else:
   vv.extend([(.63,a*.49,1.78),(.70,a*.51,1.80+.12*(1-a*a))])
 for j in range(32): k=2*j;ff.append((k,k+1,k+3,k+2))
 mesh('Curved roof brow',vv,ff,red)
# Roof crown grid with shoulders connecting to window frames.
vv=[];ff=[]
for i in range(33):
 t=i/32;x=-.29+.99*t
 for j in range(33):
  s=-1+2*j/32;y=s*(.53-.02*t);z=1.80+.12*(1-s*s)+.045*sin(pi*t);vv.append((x,y,z))
for i in range(32):
 for j in range(32):a=i*33+j;ff.append((a,a+1,a+34,a+33))
o=mesh('Terracotta domed roof',vv,ff,red);sol=o.modifiers.new('Roof thickness','SOLIDIFY');sol.thickness=.025
for side in [-1,1]:
 sidepts=[(-.59,side*.626,1.075),(-.20,side*.535,1.79),(.59,side*.515,1.80),(.94,side*.61,1.09)]
 boundary=rounded(sidepts,8,.23);mesh('Side glazing',boundary,[tuple(range(len(boundary)))],glass,False)
 tube('Terracotta side window surround',boundary,.047,red,cyclic=True);tube('Side window rubber',boundary,.023,black,cyclic=True);tube('Window chrome reveal',boundary,.008,chrome,cyclic=True)
 # broad rear quarter pillars
 pts=[(.58,side*.52,1.80),(.72,side*.51,1.79),(1.06,side*.59,1.07),(.90,side*.63,1.07)]
 mesh('Rear terracotta quarter pillar',pts,[(0,1,2,3)],red)
 tube('A pillar',[(-.64,side*.60,1.07),(-.23,side*.54,1.80)],.042,red)
 tube('Door window upright',[(.44,side*.625,1.08),(.43,side*.53,1.79)],.017,steel)
 # door outline conforming to body side
 pts=[(-.59,side*.707,1.04),(-.64,side*.711,.79),(-.55,side*.684,.51),(.47,side*.684,.51),(.55,side*.711,.78),(.52,side*.707,1.045)]
 tube('Door panel gap',rounded(pts,6,.13),.0065,black,cyclic=True)
 for x in [-.58]:
  for z in [.66,.92]:cube('Exposed door hinge',(x,side*.726,z),(.075,.025,.037),steel,.008)
 uv('Handle escutcheon',(.33,side*.719,.98),(.082,.013,.029),steel,24,12);cyl('Door handle',(.27,side*.747,.987),(.39,side*.747,.987),.012,chrome,20)
 # running boards
 cube('Sill protector',(-.02,side*.70,.49),(1.13,.08,.055),steel,.015)
 # hood vents
 uv('Side cooling vent',(-.69,side*.715,.985),(.10,.012,.035),black,24,12)
 for xx in [-.74,-.69,-.64]:cyl('Vent bar',(xx,side*.732,.962),(xx,side*.732,1.008),.0045,steel,12)
# Nose: ellipsoidal shell lamps, oval recess, five horizontal grille bars.
uv('Oval grille recess',(-1.642,0,.755),(.045,.39,.158),black,64,24)
tube('Oval grille bright surround',[(-1.68,.395*cos(a),.755+.16*sin(a)) for a in [2*pi*i/96 for i in range(96)]],.015,chrome,cyclic=True)
for dz in [-.105,-.052,0,.052,.105]:
 width=.365*sqrt(1-(dz/.16)**2);cyl('Grille horizontal slat',(-1.69,-width,.755+dz),(-1.69,width,.755+dz),.008,steel,16)
for y in [-.23,0,.23]:cyl('Grille vertical support',(-1.69,y,.63),(-1.69,y,.88),.005,steel,12)
for side in [-1,1]:
 y=side*.525
 uv('Headlamp sculpted nacelle',(-1.38,y,.998),(.30,.155,.160),cream,40,24)
 tor('Headlamp chrome rim',(-1.645,y,1.02),.128,.018,chrome,'X',64,12)
 uv('Headlamp convex lens',(-1.66,y,1.02),(.037,.116,.116),lamp,48,24)
 # actual thin glass rib geometry
 for j in range(-5,6):
  yy=j*.018;hh=sqrt(max(0,.108**2-yy**2));cyl('Headlight lens flute',(-1.694,y+yy,1.02-hh),(-1.694,y+yy,1.02+hh),.0018,chrome,8)
 tor('Indicator bezel',(-1.624,side*.56,.75),.043,.008,steel,'X',32,8);uv('Amber front indicator',(-1.632,side*.56,.75),(.014,.037,.037),amber,24,12)
 # fender-mounted mirrors
 cyl('Mirror stalk',(-.91,side*.63,.92),(-.99,side*.80,1.32),.012,steel,16)
 uv('Mirror housing',(-.99,side*.81,1.345),(.025,.065,.071),steel,32,16);uv('Mirror face',(-.965,side*.81,1.345),(.007,.056,.062),chrome,24,12)
# Bumpers
for x in [-1.67,1.62]:
 tube('Curved chrome bumper',[(x-.015,-.64,.61),(x,-.52,.59),(x,.52,.59),(x-.015,.64,.61)],.023,steel)
 for y in [-.39,.39]:cube('Bumper mount',(x,y,.60),(.10,.055,.13),steel,.015)
# bash plate drilled holes as dark inset discs
cube('Front rally skid plate',(-1.65,0,.46),(.07,.56,.20),steel,.015)
for y in [-.18,-.09,0,.09,.18]:cyl('Skid plate perforation',(-1.691,y,.49),(-1.697,y,.49),.025,black,20)
# chassis, axles, springs
cube('Ladder chassis',(0,0,.42),(2.8,.83,.12),black,.025)
for x in [-1.07,1.02]:
 cyl('Axle housing',(x,-.76,.43),(x,.76,.43),.045,steel)
 uv('Differential',(x,0,.43),(.15,.17,.13),steel)
 for s in [-1,1]:
  cyl('Suspension damper',(x-.13,s*.52,.37),(x+.04,s*.52,.72),.026,steel,24)
  pts=[(x+.04+.061*cos(t),s*.52+.061*sin(t),.42+.29*t/(12*pi)) for t in [12*pi*i/144 for i in range(145)]];tube('Terracotta coil spring',pts,.010,red)
  cyl('Wishbone',(x-.24,s*.32,.39),(x,s*.70,.43),.023,steel,20)
# Wheels: rotationally authored tire casing, deeply visible tread blocks and recessed steel rims.
for wi,x in enumerate([-1.07,1.02]):
 for s in [-1,1]:
  yc=s*.735; zc=.435; vv=[];ff=[]
  profile=[(-.145,.285),(-.146,.335),(-.125,.396),(-.088,.425),(-.045,.433),(.045,.433),(.088,.425),(.125,.396),(.146,.335),(.145,.285)]
  for i in range(80):
   a=2*pi*i/80
   for yy,r in profile:vv.append((x+r*cos(a),yc+yy,zc+r*sin(a)))
  for i in range(80):
   for j in range(len(profile)-1):a=i*len(profile)+j;b=((i+1)%80)*len(profile)+j;ff.append((a,b,b+1,a+1))
  mesh('Tire casing %s %s'%(wi,s),vv,ff,rubber)
  # tread blocks as slanted quadrilateral volumes, no bevel modifier
  vv=[];ff=[]
  for i in range(52):
   for row in [-1,0,1]:
    a=2*pi*(i+(row%2)*.45)/52;ym=yc+row*.073;dr=.431 if row==0 else .421;start=len(vv)
    for rr in [dr,dr+.009]:
     for da,dy in [(-.044,-.029),(.044,-.029),(.053,.029),(-.035,.029)]:vv.append((x+rr*cos(a+da),ym+dy,zc+rr*sin(a+da)))
    ff.extend([tuple(start+k for k in q) for q in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]])
  mesh('Chevron tire tread %s %s'%(wi,s),vv,ff,rubber,False)
  outside=yc+s*.147
  tor('Sidewall molded shoulder',(x,outside,zc),.365,.004,rubber,'Y',64,6)
  cyl('Wheel barrel',(x,yc-.11,zc),(x,yc+.11,zc),.279,steel,64)
  tor('Rolled steel rim lip',(x,outside+s*.006,zc),.268,.017,chrome,'Y',64,10)
  uv('Pressed concave steel wheel',(x,outside,zc),(.25,.027,.25),steel,48,20)
  for i in range(10):
   a=2*pi*i/10;xx=x+.194*cos(a);zz=zc+.194*sin(a)
   uv('Wheel ventilation recess',(xx,outside+s*.027,zz),(.028,.004,.035),black,16,8)
  uv('Domed hubcap',(x,outside+s*.04,zc),(.106,.053,.106),chrome,40,20)
  for i in range(5):
   a=2*pi*i/5;cyl('Wheel lug',(x+.123*cos(a),outside,zc+.123*sin(a)),(x+.123*cos(a),outside+s*.044,zc+.123*sin(a)),.013,steel,6)
# Close roof shoulder seams with smoothly rounded metal gutters.
for s in [-1,1]:
 tube('Continuous roof shoulder',[(-.29,s*.53,1.80),(-.14,s*.535,1.81),(.20,s*.525,1.81),(.59,s*.515,1.80),(.70,s*.51,1.80)],.025,red)
# Basic visible cabin interior
cube('Cabin floor',(.1,0,.78),(1.35,1.07,.08),black,.03)
for s in [-1,1]:
 seat=cube('Seat cushion',(.27,s*.29,1.0),(.49,.44,.13),leather,.065)
 seat=cube('Seat back',(.55,s*.29,1.31),(.13,.44,.55),leather,.065);seat.rotation_euler[1]=-.13
 for yy in [-.12,0,.12]:tube('Seat stitched piping',[(.47,s*.29+yy,1.09),(.47,s*.29+yy,1.49)],.003,steel)
cube('Dashboard',(-.45,0,1.13),(.21,1.10,.18),leather,.06)
cyl('Steering column',(-.37,-.29,1.12),(-.05,-.29,1.33),.018,steel)
o=tor('Bakelite steering wheel',(-.06,-.29,1.34),.145,.012,black,'X',48,10);o.rotation_euler[1]=pi/2-.45
for a in [0,2*pi/3,4*pi/3]:cyl('Steering spoke',(-.06,-.29,1.34),(-.06,-.29+.135*cos(a),1.34+.135*sin(a)),.006,steel,12)
cyl('Gear lever',(.03,0,.84),(.08,0,1.09),.009,steel,16);uv('Gear knob',(.08,0,1.10),(.027,.027,.027),black,20,12)
# Twin wipers
for y in [-.27,.25]:
 tube('Wiper arm',[(-.64,y,1.09),(-.53,y-.12,1.28)],.006,steel);tube('Wiper blade',[(-.57,y-.25,1.24),(-.49,y+.02,1.37)],.008,black)
# Rear engine lid, vents, lights and luggage rack
for i in range(7):
 z=.78+i*.039;x=1.61-.035*(i/6)
 uv('Rear engine cooling slot',(x,0,z),(.013,.29-i*.008,.011),black,32,8)
for s in [-1,1]:
 for z,m in [(.79,tail),(.89,amber)]:
  tor('Tail lamp bezel',(1.57,s*.55,z),.047,.009,steel,'X',32,8);uv('Rear lamp',(1.59,s*.55,z),(.018,.041,.041),m,24,12)
 for x in [.97,1.35]:cyl('Rack foot',(x,s*.30,1.06),(x,s*.30,1.15),.012,steel,16)
 tube('Luggage rack rail',[(.96,s*.36,1.15),(1.4,s*.36,1.15)],.014,steel)
for x in [.99,1.12,1.25,1.38]:cyl('Rack crossbar',(x,-.36,1.15),(x,.36,1.15),.010,steel,16)
# Exhaust with open dark mouth
cyl('Exhaust bent inlet',(1.05,.39,.36),(1.42,.60,.41),.043,steel,32)
cyl('External exhaust silencer',(1.38,.60,.41),(1.85,.68,.63),.077,steel,48)
cyl('Exhaust dark opening',(1.849,.68,.63),(1.858,.681,.635),.063,black,32)
# restrained irregular chips along lower sill and body edges, visible geometry decals
for s in [-1,1]:
 for i in range(32):
  x=random.uniform(-.53,.5);z=random.choice([random.uniform(.51,.57),random.uniform(.95,1.01)]);y=s*.708
  siz=random.uniform(.003,.012);mesh('Small enamel wear',[(x,y,z),(x+siz*2,y,z+.003),(x+siz,y,z+siz),(x-.003,y,z+siz*.3)],[(0,1,2,3)],steel,False)
# Consolidate curve conversions and apply modifiers for deterministic export audit.
bpy.ops.object.select_all(action='DESELECT')
for o in list(car.objects):o.select_set(True)
bpy.context.view_layer.objects.active=body;bpy.ops.object.convert(target='MESH')
for o in list(car.objects):
 bpy.context.view_layer.objects.active=o
 for mod in list(o.modifiers):
  try:bpy.ops.object.modifier_apply(modifier=mod.name)
  except:pass
# Reduce dense curved secondary meshes while retaining silhouette and material seams.
for o in list(car.objects):
 if o.type=='MESH' and len(o.data.polygons)>180:
  bpy.context.view_layer.objects.active=o
  dec=o.modifiers.new('Mid-poly export optimization','DECIMATE');dec.ratio=.64
  bpy.ops.object.modifier_apply(modifier=dec.name)
# Match the compact, low canopy proportions of the reference.
for o in car.objects:
 if o.type=='MESH':
  for v in o.data.vertices:
   world=o.matrix_world @ v.co
   if world.z>1.05:
    world.z=1.05+(world.z-1.05)*.74
    v.co=o.matrix_world.inverted() @ world
# Root with axes and separable components retained
root=bpy.data.objects.new('Sparrow One | meters | front -X',None);car.objects.link(root)
for o in list(car.objects):
 if o!=root:o.parent=root
# Export vehicle only
bpy.ops.object.select_all(action='DESELECT')
for o in car.objects:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'Sparrow_One.glb'),export_format='GLB',use_selection=True,export_apply=True)
tris=0;polys=0;verts=0
for o in car.objects:
 if o.type=='MESH':o.data.calc_loop_triangles();tris+=len(o.data.loop_triangles);polys+=len(o.data.polygons);verts+=len(o.data.vertices)
json.dump({'triangles':tris,'polygons':polys,'vertices':verts,'mesh_objects':sum(o.type=='MESH' for o in car.objects),'scope':'vehicle only, studio excluded','units':'meters','front_axis':'-X','note':'Reference-inspired exterior with simplified interior; not dimensioned engineering replica.'},open(os.path.join(OUT,'geometry_audit.json'),'w'),indent=2)
print('AUDIT',tris,polys,verts,flush=True)
# Studio
studio=bpy.data.collections.new('STUDIO • excluded from GLB');bpy.context.scene.collection.children.link(studio)
def st(o):
 for c in list(o.users_collection):c.objects.unlink(o)
 studio.objects.link(o)
bpy.ops.mesh.primitive_plane_add(size=200);o=bpy.context.object;o.name='Studio floor';st(o);o.data.materials.append(mat('Warm studio',(.72,.70,.65),0,.8))
world=bpy.context.scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.73,.78,.84,1);world.node_tree.nodes['Background'].inputs[1].default_value=.35
for name,loc,power,size in [('Key',(-3,-4,7),1300,5),('Fill',(-1,4,4),900,4),('Rim',(4,1,6),1500,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;st(o);o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,.7))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(-4.6,-5.2,2.8));cam=bpy.context.object;st(cam);cam.data.type='ORTHO';cam.data.ortho_scale=4.6
scene=bpy.context.scene;scene.camera=cam;scene.render.engine='CYCLES';scene.cycles.samples=256;scene.cycles.use_denoising=False;scene.render.resolution_x=1500;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX';scene.view_settings.exposure=-.45;scene.render.image_settings.file_format='PNG'
def aim():cam.rotation_euler=(Vector((0,0,.97))-cam.location).to_track_quat('-Z','Y').to_euler()
aim();bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'Sparrow_One.blend'))
scene.render.filepath=os.path.join(OUT,'preview_front.png');bpy.ops.render.render(write_still=True)
cam.location=(4.6,5.2,2.8);aim();scene.render.filepath=os.path.join(OUT,'preview_rear.png');bpy.ops.render.render(write_still=True)
